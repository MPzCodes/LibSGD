Sprites
======

Sprites...

Types
-----

.. doxygengroup:: SpriteTypes
    :content-only:

Functions
---------

.. doxygengroup:: Sprite
    :content-only:
