Window
======

To create a window, use :any:`sgd_CreateWindow`.

Types
-----

.. doxygengroup:: WindowTypes
    :content-only:

Functions
---------

.. doxygengroup:: Window
    :content-only:
