Core
====

These are the core types and constants used by LibSGD.

Types
-----

.. doxygengroup:: CoreTypes
    :content-only:

Constants
---------

.. doxygengroup:: CoreConsts
    :content-only:
